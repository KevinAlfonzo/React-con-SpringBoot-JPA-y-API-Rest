package com.demoswrest.demoswrest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Empleado")
public class Empleado {
    
    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY)
    private int IDEMP;
    @Column(name = "Nombre")
    private String NOMEMP;
    @Column(name = "Apellido")
    private String APEEMP;
    @Column(name = "Celular", unique = true, length = 9)
    private String CELEMP;
    @Column(name = "Email")
    private String EMAEMP;
    @Column(name= "DNI", unique = true, length = 8)
    private String DNIEMP;
    @Column(name = "Estado")
    private String ESTEMP;

    public int getIDEMP() {
        return IDEMP;
    }

    public void setIDEMP(int IDEMP) {
        this.IDEMP = IDEMP;
    }

    public String getNOMEMP() {
        return NOMEMP;
    }

    public void setNOMEMP(String NOMEMP) {
        this.NOMEMP = NOMEMP;
    }

    public String getAPEEMP() {
        return APEEMP;
    }

    public void setAPEEMP(String APEEMP) {
        this.APEEMP = APEEMP;
    }

    public String getCELEMP() {
        return CELEMP;
    }

    public void setCELEMP(String CELEMP) {
        this.CELEMP = CELEMP;
    }

    public String getEMAEMP() {
        return EMAEMP;
    }

    public void setEMAEMP(String EMAEMP) {
        this.EMAEMP = EMAEMP;
    }

    public String getDNIEMP() {
        return DNIEMP;
    }

    public void setDNIEMP(String DNIEMP) {
        this.DNIEMP = DNIEMP;
    }

    public String getESTEMP() {
        return ESTEMP;
    }

    public void setESTEMP(String ESTEMP) {
        this.ESTEMP = ESTEMP;
    }
    
    
}
