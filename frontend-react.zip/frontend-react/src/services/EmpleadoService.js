import axios from 'axios';

const EMPLEADO_BASE_REST_API_URL= 'http://localhost:7070/empleado';

class EmpleadoService{
    
    getAllEmpleado(){
        return axios.get(EMPLEADO_BASE_REST_API_URL)
    }
}

export default new EmpleadoService();