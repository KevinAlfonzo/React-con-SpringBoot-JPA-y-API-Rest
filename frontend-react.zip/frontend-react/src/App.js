import './App.css';
import ListEmpleadoComponents from './components/ListEmpleadoComponents';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';

function App() {
  return (
    <div>
        <HeaderComponent/>
        <ListEmpleadoComponents/>
        <FooterComponent/>
    </div>
  );
}

export default App;
