import React, {useEffect, useState} from 'react'
import EmpleadoService from '../services/EmpleadoService'

const ListEmpleadoComponents = () => {

    const [empleados, setEmpleado] = useState([])

    useEffect(() => {

        EmpleadoService.getAllEmpleado().then((response) => {
            setEmpleado(response.data)
            console.log(response.data);
        }).catch(error => {
            console.log('Hola' + error);
        })
    }, [])
    

  return (
    <div className='container'>
        <h2 className='text-center'> Empleados </h2>
        <table className='table table-bordered table-striped'>
            <thead className='columnas'>
                <th> Id</th>
                <th> Nombre</th>
                <th> Apellidos</th>
                <th> Email</th>
                <th> Celular</th>
                <th> Estado</th>
            </thead>
            <tbody>
                {
                    empleados.map(  
                        empleado =>
                        <tr key = {empleado.id}>
                            <td> {empleado.id} </td>
                            <td> {empleado.nombre} </td>
                            <td> {empleado.apellido} </td>
                            <td> {empleado.email} </td>
                            <td> {empleado.celular} </td>
                            <td> {empleado.estado} </td>
                        </tr>
                    )
                }
            </tbody>
        </table>
    </div>
  )
}

export default ListEmpleadoComponents