package net.javaguides.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.modelo.Empleado;
import net.javaguides.springboot.repository.EmpleadoRepository;

@Service
public class EmpleadoService {

	@Autowired
	private EmpleadoRepository empleadoRepository;
	
	public List<Empleado> findAll() {
		return empleadoRepository.findAll();
	}
	
	public List<Empleado> findAll(Sort sort) {
		return empleadoRepository.findAll(sort);
	}
	
	public List<Empleado> finById(Long id) {
		return null;
	}
	
	public Empleado getById(Long id) {
		return null;
	}
	
	public <S extends Empleado> S save(S entity) {
		return empleadoRepository.save(entity);
	}
	
	public void deleteById(Long id) {
		empleadoRepository.deleteById(id);
	}
}
