package net.javaguides.springboot.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "EMPLEADO")
public class Empleado {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "Nombre", nullable = false)
	private String Nombre;
	
	@Column(name = "Apellido", nullable = false)
	private String Apellido;
	
	@Column(name = "Email", nullable = false)
	private String Email;
	
	@Column(name = "Celular", nullable = false)
	private String Celular;
	
	@Column(name = "Estado", nullable = false)
	private String Estado;
	
	public Empleado() {
		
	}

	public Empleado(String nombre, String apellido, String email, String celular, String estado) {
		super();
		Nombre = nombre;
		Apellido = apellido;
		Email = email;
		Celular = celular;
		Estado = estado;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getCelular() {
		return Celular;
	}

	public void setCelular(String celular) {
		Celular = celular;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

}
